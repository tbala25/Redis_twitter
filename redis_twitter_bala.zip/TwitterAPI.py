import datetime
import redis
import csv
import pandas as pd


class Tweet:
    userID = 0
    tweetTime = ''
    tweet = ""
    tweetID = 0

    def get_userID(self):
        return self.userID

    def get_tweetTime(self):
        return self.tweetTime

    def get_tweet(self):
        return self.tweet

    def set_userID(self, userID):
        self.userID = userID
        return self.userID

    def set_tweetTime(self, time):
        self.tweetTime = time
        return self.tweetTime

    def set_tweet(self, tweetText):
        self.tweet = tweetText
        return self.tweet

    def get_tweetID(self):
        return self.tweetID

    def set_tweetID(self, twID):
        self.tweetID = twID


class TwitterAPI:
    def postTweet(self, tweet):
        pass

    def addFollower(self, follwerID, userID):
        pass

    def getTimeline(self, userID, numTweets):
        pass

    def getFollowers(self, userID):
        pass


class RedisTwitterAPI(TwitterAPI):

    # create redis connection here
    r = redis.StrictRedis(host='localhost', port=6379, db=0)

    def postTweet(self, t):
        tweet = t.get_tweet()
        user = t.get_userID()
        tt = t.get_tweetTime()
        tid = t.get_tweetID()

        #hmset userid:postid user_id $owner_id time $time body "I'm having fun with Retwis"

        keyname = str(user) + ":" + str(tid)
        values = {'user_id': user, 'time': tt, 'tweet': tweet}

        self.r.hmset(keyname, values)

        return True

    def addFollower(self, followerID, userID):

        # set
        # sADD followers:userID  followerID
        # sadd following:followerID userID

        key1 = 'followers:' + userID
        key2 = 'following:' + followerID

        self.r.sadd(key1, followerID)
        self.r.sadd(key2, userID)
        return True

    def getTimeline(self, userID, numTweets):
        #query
        #keys userid:*
        #iterate through returned list

        key2 = 'following:' + userID
        following = self.r.smembers(key2)
        timelineTweets = list()
        timelineTimes = list()
        timelineUserID = list()

        # for each user 'userID' is following
        for f in following:
            # get userID and matching key from tweet hash
            key = f[10, ]
            pattern = key + ':'
            list_of_keys = self.r.keys(pattern)

            # for each key in list of keys
            for k in list_of_keys:
                # get tweet values
                list_of_userid = list_of_userid.append(self.r.hget(k, 'user_id'))
                list_of_tweets = list_of_tweets.append(self.r.hget(k, 'tweet'))
                list_of_times = list_of_times.append(self.r.hget(k, 'time'))

            timelineTweets.extend(list_of_tweets)
            timelineTimes.extend(list_of_times)
            timelineUserID.extend(list_of_userid)

        timeline_df = pd.DataFrame({'user_id': timelineUserID, 'tweet': timelineTweets, 'time': timelineTimes})
        timeline_df.sort_values(by=['time'], ascending=True)

        return timeline_df

    def getFollowers(self, userID):

        # used in strategy 2

        key1 = 'followers:' + userID
        followers = self.r.smembers(key1)

        return followers

    def addToTimelime(self, userID, t):

        # used for strategy 2

        return True


class TwitterTester:

    api = RedisTwitterAPI()
    #create file read in and out

    # with open('followers.csv') as csvfile:
    #
    #     followerreader = csv.reader(csvfile, delimiter='\n')
    #     for row in followerreader:
    #         # print(row)
    #         user = row[0].split(';')[0]
    #         # print(user)
    #         following = row[0].split(';')[1]
    #         api.addFollower(user, following)

    with open('tweets.csv') as tweetfile:

        tweetreader = csv.reader(tweetfile, delimiter='\n')
        for row in tweetreader:
            tweet = Tweet()
            tweetline = row[0].split(',')
            print(tweetline)
            tweetID = tweetline[0].split(':')[1]
            userID = tweetline[1].split(':')[1]
            tweetTS = tweetline[2].split(':')[1] + tweetline[2].split(':')[2] + tweetline[2].split(':')[3]
            tweetText = tweetline[3].split(':')[1]

            tweet.set_tweetID(tweetID)
            tweet.set_tweet(tweetText)
            tweet.set_userID(userID)
            tweet.set_tweetTime(tweetTS)

            api.postTweet(tweet)

    print(api.getTimeline(10, 150))